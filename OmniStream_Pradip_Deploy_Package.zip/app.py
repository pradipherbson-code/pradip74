import sys
from pathlib import Path

# Add current root directory to sys.path for backend package resolution
root_dir = Path(__file__).resolve().parent
if str(root_dir) not in sys.path:
    sys.path.insert(0, str(root_dir))

from backend.app import app
